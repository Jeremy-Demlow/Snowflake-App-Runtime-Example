__version__ = "0.1.0"

# --- cocosdkagent native surface ---
from .core import (
    models,
    ModelPrice, MODEL_PRICES, DEFAULT_CREDIT_PRICE_USD,
    Usage, Message, UserTurn, ToolResult,
    Client, Chat,
    TextDelta, ThinkingDelta, ToolUseStart, ToolUseInputDelta, ToolUseEnd,
    list_mcps, list_mcps_detailed,
    list_skills, list_skills_detailed,
    tool_from_fn,
)
from .toolloop import (
    tool, create_sdk_mcp_server,
)
from .async_ import (
    AsyncClient, AsyncChat,
)
from .cortex import (
    Agent, audit_log, audit_to_list, block_tools, sql_read_only_guard,
    HookError, HookEventName, DEFAULT_HOOK_TIMEOUT,
)

# --- SDK message / block type re-exports (P0.5 lock-in #10) ---
# Consumers should never need `from cortex_code_agent_sdk import ...` directly.
from cortex_code_agent_sdk import (
    AssistantMessage, UserMessage, SystemMessage, ResultMessage, StreamEvent,
    TextBlock, ThinkingBlock, ToolUseBlock, ToolResultBlock,
    CortexCodeAgentOptions, HookMatcher, AgentDefinition, SnowflakeSandboxOptions,
    SdkMcpTool,
)

# --- Sub-namespace shortcuts ---
from . import cortex as hooks  # alias `cocosdkagent.hooks` -> `cocosdkagent.cortex`
import sys as _sys
_sys.modules['cocosdkagent.hooks'] = hooks  # so `from cocosdkagent.hooks import X` works

__all__ = [
    # cocosdkagent native
    'models',
    'ModelPrice', 'MODEL_PRICES', 'DEFAULT_CREDIT_PRICE_USD',
    'Usage', 'Message', 'UserTurn', 'ToolResult',
    'Client', 'Chat',
    'AsyncClient', 'AsyncChat',
    'TextDelta', 'ThinkingDelta', 'ToolUseStart', 'ToolUseInputDelta', 'ToolUseEnd',
    'tool', 'create_sdk_mcp_server', 'tool_from_fn',
    'Agent', 'audit_log', 'audit_to_list', 'block_tools', 'sql_read_only_guard',
    'HookError', 'HookEventName', 'DEFAULT_HOOK_TIMEOUT',
    'list_mcps', 'list_mcps_detailed',
    'list_skills', 'list_skills_detailed',
    # SDK passthroughs
    'AssistantMessage', 'UserMessage', 'SystemMessage', 'ResultMessage', 'StreamEvent',
    'TextBlock', 'ThinkingBlock', 'ToolUseBlock', 'ToolResultBlock',
    'CortexCodeAgentOptions', 'HookMatcher', 'AgentDefinition', 'SnowflakeSandboxOptions',
    'SdkMcpTool',
    # Subnamespace
    'hooks',
]
