"""Feature-detect what the installed `cortex-code-agent-sdk` supports.

This module is the **single seam** to update when SDK upgrades land
natively-supported features. Today (SDK 1.0.2) several `CortexCodeAgentOptions`
fields are accepted but never reach the CLI (TODOs in
`subprocess_cli.py:141-165`); when those wire through, the flags below flip
without any consumer-visible churn.

See also: ``UPSTREAM.md`` for the full watch list.
"""
from __future__ import annotations

import dataclasses
import logging
import re
import shutil
import subprocess
from typing import Final

from cortex_code_agent_sdk import CortexCodeAgentOptions

_log = logging.getLogger('cocosdkagent.compat')

# Field set introspected once at import time. Cheap and stable.
try:
    _FIELDS: frozenset[str] = frozenset(
        f.name for f in dataclasses.fields(CortexCodeAgentOptions)
    )
except Exception:  # pragma: no cover -- SDK shape changed drastically
    _log.warning('Could not introspect CortexCodeAgentOptions fields; assuming nothing native.')
    _FIELDS = frozenset()


# DELETE-WHEN: SDK ships a native `mode` field on CortexCodeAgentOptions.
# When `HAS_NATIVE_MODE` becomes True, `_opts()` automatically prefers
# `kw['mode'] = mode` over `extra_args={'mode': mode}` -- zero churn for
# consumers of `Chat(mode='code')`.
#
# Today (SDK 1.0.2): False. The dataclass has no `mode` field.
HAS_NATIVE_MODE: Final[bool] = 'mode' in _FIELDS

# CAUTION: dataclass-presence != transport-wired. Today (SDK 1.0.2) the
# dataclass HAS `tools=` and `system_prompt=` fields, but `subprocess_cli.py`
# never emits the corresponding CLI flags (TODOs at lines 141-165). So these
# flags being True is NECESSARY but NOT SUFFICIENT for the kwarg to work.
#
# Use these as breadcrumbs ("the SDK author intends this to exist") rather
# than as proof the kwarg actually works. To verify wiring, run
# `scripts/probe_tools_flags.py` and look at init `tools_count`.
DATACLASS_HAS_TOOLS_FIELD: Final[bool] = 'tools' in _FIELDS
DATACLASS_HAS_SYSPROMPT_FIELD: Final[bool] = 'system_prompt' in _FIELDS

# Backwards-compat aliases (deprecated naming; will remove in next major).
# DELETE-WHEN: 1.0.0 release; downstream switched to DATACLASS_HAS_*_FIELD.
HAS_NATIVE_TOOLS: Final[bool] = DATACLASS_HAS_TOOLS_FIELD
HAS_NATIVE_SYSPROMPT: Final[bool] = DATACLASS_HAS_SYSPROMPT_FIELD


def get_sdk_version() -> str:
    "Return the installed `cortex-code-agent-sdk` package version, or 'unknown'."
    try:
        from importlib.metadata import version
        return version('cortex-code-agent-sdk')
    except Exception:
        return 'unknown'


# CLI floor pulled from `subprocess_cli.py:23` (MINIMUM_CLI_VERSION).
# Keep in sync; bump if a newer SDK requires a higher floor.
MINIMUM_CLI_VERSION: Final[str] = '1.0.49'

_VERSION_CHECK_CACHE: dict[str, str | None] = {}


def get_cli_version() -> str | None:
    """Return the `cortex --version` string (e.g. '1.0.84'), or None if not on PATH.

    Cached after first successful call.
    """
    if 'version' in _VERSION_CHECK_CACHE:
        return _VERSION_CHECK_CACHE['version']
    if shutil.which('cortex') is None:
        _VERSION_CHECK_CACHE['version'] = None
        return None
    try:
        out = subprocess.check_output(['cortex', '--version'], text=True, timeout=5)
        m = re.search(r'(\d+\.\d+\.\d+)', out)
        v = m.group(1) if m else None
    except Exception as e:
        _log.debug('cortex --version probe failed: %s', e)
        v = None
    _VERSION_CHECK_CACHE['version'] = v
    return v


def _vtuple(v: str) -> tuple[int, ...]:
    return tuple(int(p) for p in v.split('.'))


def assert_cli_version(minimum: str = MINIMUM_CLI_VERSION,
                       *, skip: bool = False) -> None:
    """Raise RuntimeError if the cortex CLI on PATH is older than `minimum`.

    Pass ``skip=True`` (or ``Chat(skip_version_check=True)``) to bypass.
    Soft-warns if the CLI isn't on PATH at all (some environments use a
    pre-baked subprocess path; we don't want to be wrong about that).
    """
    if skip:
        return
    actual = get_cli_version()
    if actual is None:
        _log.warning(
            'cortex CLI not found on PATH; cocosdkagent assumes the SDK will '
            'find it. To suppress: `Chat(skip_version_check=True)`.'
        )
        return
    if _vtuple(actual) < _vtuple(minimum):
        raise RuntimeError(
            f"cocosdkagent requires cortex CLI >= {minimum}; got {actual}. "
            f"Run `cortex update` to upgrade, or pass "
            f"`Chat(skip_version_check=True)` to bypass."
        )


__all__ = [
    'HAS_NATIVE_MODE',
    'DATACLASS_HAS_TOOLS_FIELD', 'DATACLASS_HAS_SYSPROMPT_FIELD',
    'HAS_NATIVE_TOOLS', 'HAS_NATIVE_SYSPROMPT',  # deprecated aliases
    'MINIMUM_CLI_VERSION',
    'get_sdk_version', 'get_cli_version', 'assert_cli_version',
]
