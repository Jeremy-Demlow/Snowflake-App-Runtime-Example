"""Streamlit helpers for cocosdkagent.

This module is imported lazily and requires `streamlit`. Install with::

    pip install streamlit pandas

State ownership
---------------
`StreamlitChat` lives in `st.session_state['chat']`. It survives Streamlit
page reruns within the same browser session. It does NOT survive process
restart -- use ``Chat.dump()`` / ``Chat.from_dump()`` to persist across
cold starts. The full pattern::

    if 'chat' not in st.session_state:
        from cocosdkagent import Chat
        st.session_state.chat = Chat(model='claude-opus-4-7', mcp=False)

    chat = st.session_state.chat

Live-refresh patterns
---------------------
The cocosdkagent background loop runs in a daemon thread that does NOT hold
a Streamlit ``ScriptRunContext``. Calling ``st.rerun()`` from there logs
``missing ScriptRunContext`` and silently no-ops. The supported pattern is
``auto_refresh`` (uses ``st.fragment(run_every=...)`` under the hood):

    from cocosdkagent.streamlit import auto_refresh, render_status_strip
    auto_refresh(sc.chat, render_status_strip, interval=1.0)

Requires Streamlit >= 1.32 for ``st.fragment``.
"""
from __future__ import annotations

from typing import Any, Callable
import warnings

try:
    import streamlit as st  # noqa: F401
except ImportError as e:  # pragma: no cover
    raise ImportError(
        "cocosdkagent.streamlit requires streamlit. `pip install streamlit pandas`."
    ) from e

from .core import Chat, ToolResult, _block_text


__all__ = [
    'render_tool_result', 'render_status_strip',
    'auto_refresh', 'make_heartbeat',
    'StreamlitChat',
]


# ---- internal helpers --------------------------------------------------

def _stretch_kwargs():
    """Return the right kwargs dict for `width="stretch"` (Streamlit >=1.40)
    falling back to `use_container_width=True` on older versions."""
    try:
        import streamlit as _st
        ver = tuple(int(p) for p in _st.__version__.split('.')[:2])
    except Exception:
        ver = (0, 0)
    if ver >= (1, 40):
        return {'width': 'stretch'}
    return {'use_container_width': True}


def _looks_like_csv(body: str, expected_rows: int | None) -> bool:
    """Heuristic that says 'this body is CSV-shaped'. Avoids false-positives
    on prose answers like "Yes, that's correct."

    Requires:
    - at least 2 lines
    - first line has at least one comma
    - second line has the same comma count as the first (header consistency)
    - no run of 3+ spaces in the header (CSV headers don't have prose spacing)
    """
    lines = body.splitlines()
    if len(lines) < 2: return False
    header, second = lines[0], lines[1]
    h_commas = header.count(',')
    if h_commas < 1: return False
    if second.count(',') != h_commas: return False
    if '   ' in header: return False
    # If the preamble told us how many rows to expect, sanity-check against
    # body line count (header + N rows, give or take trailing newline).
    if expected_rows is not None and len(lines) - 1 < expected_rows - 1:
        return False
    return True


# ---- public surface ----------------------------------------------------

def render_tool_result(block, *, tool_name: str | None = None) -> None:
    """Render a `ToolResultBlock` (or a `ToolResult` wrapper) into the
    current Streamlit container, picking the best widget for the payload.

    - SQL CSV results -> ``st.dataframe`` (preamble stripped)
    - JSON blobs -> ``st.json``
    - Markdown / plain text -> ``st.markdown`` / ``st.code``
    - Errors -> ``st.error``
    """
    import streamlit as st
    tr = block if isinstance(block, ToolResult) else ToolResult(block, tool_name=tool_name)
    meta = tr.metadata
    if meta['is_error']:
        st.error(tr.text)
        return
    body = tr.as_text().strip()
    if not body:
        st.caption('_(empty result)_')
        return
    # SQL-shaped payload: trust row_count first (only set when "N row(s) returned." preamble matched),
    # then verify CSV-header consistency before parsing.
    if meta['row_count'] is not None and _looks_like_csv(body, meta['row_count']):
        try:
            df = tr.as_dataframe()
            if len(df.columns) > 0:
                st.dataframe(df, **_stretch_kwargs())
                return
        except Exception:
            pass
    # JSON
    head = body[:1].strip()
    if head in ('{', '['):
        import json
        try:
            parsed = json.loads(body)
            # Opportunistic Vega-Lite detection -- render as chart if spec-shaped.
            if isinstance(parsed, dict) and (
                'vega' in str(parsed.get('$schema', '')).lower() or
                ('mark' in parsed and 'data' in parsed) or
                ('layer' in parsed and isinstance(parsed.get('layer'), list))
            ):
                try:
                    st.vega_lite_chart(parsed, **_stretch_kwargs())
                    return
                except Exception:
                    pass
            st.json(parsed)
            return
        except Exception:
            pass
    # Plain text fallback
    st.code(body)


def render_status_strip(chat: Chat, *, extra: dict | None = None) -> None:
    """Render a header strip showing model, connection, MCP, message count, usage chip.

    Pass ``extra={'label': 'value', ...}`` for additional pills.

    Note: 'messages' counts every assistant Message in `chat.h` (multi-tool
    turns produce more than one). Use `chat.turn_count` for the user-prompt
    count -- shown as 'turns' here when available.
    """
    import streamlit as st
    cols = st.columns(6)
    cols[0].caption(f"**model:** `{chat.model}`")
    conn = chat.connection or 'default'
    cols[1].caption(f"**conn:** `{conn}`")
    mcp = chat.mcp
    if mcp is False or mcp is None: mcp_label = 'off'
    elif mcp is True:               mcp_label = 'all'
    else:                           mcp_label = str(mcp)
    cols[2].caption(f"**mcp:** `{mcp_label}`")
    cols[3].caption(f"**turns:** `{getattr(chat, 'turn_count', 0)}`")
    cols[4].caption(f"**messages:** `{len(chat.h)}`")
    cols[5].caption(
        f"**use:** in {chat.use.input_tokens} / out {chat.use.output_tokens} "
        f"/ ${chat.use.cost_usd:.4f}"
    )
    if extra:
        more = st.columns(len(extra))
        for col, (label, value) in zip(more, extra.items()):
            col.caption(f"**{label}:** `{value}`")


def auto_refresh(chat: Chat, render_fn: Callable[[Chat], None], *,
                 interval: float = 1.0, key: str = 'cocosdk_status') -> None:
    """Render `render_fn(chat)` inside a Streamlit fragment that auto-refreshes
    every `interval` seconds.

    Use this instead of `make_heartbeat` -- the SDK's background loop has
    no Streamlit ScriptRunContext, so `st.rerun()` from there silently
    no-ops. `st.fragment(run_every=...)` is the supported pattern.

    Example::

        from cocosdkagent.streamlit import auto_refresh, render_status_strip
        auto_refresh(chat, render_status_strip, interval=1.0)

    Requires Streamlit >= 1.32 for `st.fragment`.
    """
    import streamlit as st
    if not hasattr(st, 'fragment'):
        raise RuntimeError(
            "auto_refresh requires Streamlit >= 1.32 (st.fragment). "
            "Upgrade with `pip install -U streamlit`, or wire your own "
            "main-thread refresh loop."
        )

    # Wrap render_fn into a fragment with run_every; key keeps duplicate
    # calls in the same script run from racing.
    @st.fragment(run_every=interval)
    def _auto_refresh_fragment():
        render_fn(chat)

    _auto_refresh_fragment()


def make_heartbeat(chat: Chat, *, interval: float = 1.0):
    """DEPRECATED. Returns a no-op-safe callback for backward compatibility.

    The previous implementation called ``st.rerun()`` from within an
    ``on_message`` callback, but the SDK's background loop has no Streamlit
    ScriptRunContext so the rerun silently no-opped. Use ``auto_refresh``
    with ``st.fragment(run_every=...)`` instead::

        from cocosdkagent.streamlit import auto_refresh, render_status_strip
        auto_refresh(chat, render_status_strip, interval=1.0)
    """
    warnings.warn(
        "make_heartbeat is deprecated; use cocosdkagent.streamlit.auto_refresh "
        "(which uses st.fragment) instead. The SDK background thread has no "
        "Streamlit ScriptRunContext, so st.rerun() from on_message silently "
        "no-ops.",
        DeprecationWarning, stacklevel=2,
    )
    import time
    state = {'last': 0.0}

    def cb(msg: Any, c: Chat) -> None:
        now = time.monotonic()
        if now - state['last'] < interval:
            return
        state['last'] = now
        # Best-effort; from a background thread this no-ops by design.
        try:
            import streamlit as _st
            from streamlit.runtime.scriptrunner import get_script_run_ctx
            if get_script_run_ctx() is not None:
                _st.rerun()
        except Exception:
            pass

    return cb


class StreamlitChat:
    """Thin Streamlit-friendly facade around `Chat`.

    Stores the wrapped `Chat` on ``st.session_state[<key>]`` so it survives
    page reruns. Use ``StreamlitChat.get_or_create(...)`` from inside your
    Streamlit script.

    Example::

        sc = StreamlitChat.get_or_create(
            key='chat',
            model='claude-opus-4-7',
            mcp=False,
        )
        for prompt in [user_prompt]:
            for piece in sc.stream(prompt):
                # piece is one of: Message, ToolUseBlock, UserMessage, ResultMessage
                ...
        render_status_strip(sc.chat)
    """
    def __init__(self, chat: Chat):
        self.chat = chat
        # `user_prompts` is now a deprecated proxy that walks chat.h.
        # cocosdkagent.Chat.h is unified (UserTurn + Message in order).

    @property
    def user_prompts(self) -> list[str]:
        """DEPRECATED in Phase 14: walk `self.chat.h` directly to get
        interleaved user/assistant entries (each with `.role_`).

        Returns the user-side prompts in order, derived from `chat.h`.
        Will be removed in a future major version.
        """
        import warnings as _warnings
        from cocosdkagent.core import UserTurn
        _warnings.warn(
            "StreamlitChat.user_prompts is deprecated; walk chat.h directly "
            "(each entry has `.role_` of 'user' or 'assistant'). "
            "Will be removed in a future major version.",
            DeprecationWarning, stacklevel=2,
        )
        return [t.prompt for t in self.chat.h if isinstance(t, UserTurn)]

    @classmethod
    def get_or_create(cls, *, key: str = 'chat', **chat_kwargs) -> 'StreamlitChat':
        import streamlit as st
        if key not in st.session_state:
            st.session_state[key] = cls(Chat(**chat_kwargs))
        return st.session_state[key]

    def record_user_prompt(self, prompt: str) -> None:
        """DEPRECATED in Phase 14: no-op. Chat.__call__/stream now append
        UserTurn to chat.h automatically.
        """
        import warnings as _warnings
        _warnings.warn(
            "StreamlitChat.record_user_prompt is a no-op since Phase 14; "
            "Chat.__call__ and Chat.stream now append UserTurn to chat.h "
            "automatically. Will be removed in a future major version.",
            DeprecationWarning, stacklevel=2,
        )

    def stream(self, prompt: str):
        "Yield typed messages from `chat.stream(prompt)` (delegates)."
        yield from self.chat.stream(prompt)

    def __call__(self, prompt: str, **kw):
        "Run a single turn synchronously."
        return self.chat(prompt, **kw)

    def reset(self) -> None:
        "Close the underlying Chat and remove it from session_state."
        import streamlit as st
        try: self.chat.close()
        except Exception: pass
        for k, v in list(st.session_state.items()):
            if v is self: del st.session_state[k]
